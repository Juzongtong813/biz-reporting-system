import { Module, OnModuleInit } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersService } from './users/users.service';

// 核心业务模块
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { PackagesModule } from './packages/packages.module';
import { ContractsModule } from './contracts/contracts.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { CityConfigsModule } from './city-configs/city-configs.module';
import { OperationLogsModule } from './operation-logs/operation-logs.module';
import { CitiesModule } from './cities/cities.module';

@Module({
  imports: [
    // 环境变量配置
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
    }),

    // TypeORM 数据库连接（支持 MySQL / SQLite 切换）
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const dbType = config.get<string>('DB_TYPE', 'mysql');

        if (dbType === 'sqlite') {
          return {
            type: 'better-sqlite3' as any,
            database: config.get<string>('DB_DATABASE', './data/dev.sqlite'),
            entities: [__dirname + '/**/*.entity.ts', __dirname + '/**/*.entity.js'],
            synchronize: config.get<boolean>('DB_SYNC', true),
            logging: config.get<boolean>('DB_LOGGING', false),
          };
        }

        return {
          type: 'mysql' as any,
          host: config.get<string>('DB_HOST', 'localhost'),
          port: config.get<number>('DB_PORT', 3306),
          username: config.get<string>('DB_USERNAME', 'root'),
          password: config.get<string>('DB_PASSWORD', ''),
          database: config.get<string>('DB_DATABASE', 'biz_reporting'),
          charset: 'utf8mb4',
          entities: [__dirname + '/**/*.entity.ts', __dirname + '/**/*.entity.js'],
          synchronize: config.get<boolean>('DB_SYNC', false),
          logging: config.get<boolean>('DB_LOGGING', false),
        };
      },
    }),

    // 业务模块
    AuthModule,
    UsersModule,
    PackagesModule,
    ContractsModule,
    DashboardModule,
    CityConfigsModule,
    OperationLogsModule,
    CitiesModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements OnModuleInit {
  constructor(private readonly usersService: UsersService) {}

  async onModuleInit() {
    await this.usersService.seedAdminIfNeeded();
  }
}